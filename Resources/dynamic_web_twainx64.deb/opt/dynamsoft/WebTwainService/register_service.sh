#!/bin/sh
var=99
while :
do
PROCESS_NUM=`find /etc/rcS.d -name "*""$var""*"| wc -l` 
if [ $PROCESS_NUM -eq 0 ]; then
	ln -s /etc/init.d/WebTwainServiced "/etc/rcS.d/S""$var""WebTwainServiced"
	break
else
	var=`expr $var + 1`
fi
done
